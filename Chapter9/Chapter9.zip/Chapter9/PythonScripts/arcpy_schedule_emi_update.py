import arcpy
from datetime import datetime, timedelta

########################################################################################
## USER INPUT ##########################################################################

updated_fl = arcpy.GetParameterAsText(0)

master_fl = arcpy.GetParameterAsText(1)

scores_csv = arcpy.GetParameterAsText(2)

########################################################################################
## GET THE SCORES ######################################################################

scores_dict = {
    row[0] : row[1]
    for row in arcpy.da.SearchCursor(
        in_table = scores_csv,
        field_names = ["BUILDING_TYPE", "SENSITIVITY_SCORE"]
    )
}

########################################################################################
## DEFINE SQL WHERE CLAUSE #############################################################

today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
tomorrow = today + timedelta(days=1)

where_clause = f"EditDate >= DATE '{today:%Y-%m-%d %H:%M:%S}' AND EditDate < DATE '{tomorrow:%Y-%m-%d %H:%M:%S}' AND assessed = 'Yes'"

########################################################################################
## GET THE CHANGES #####################################################################

update_dict = {
    row[0] : row[1]
    for row in arcpy.da.SearchCursor(
        in_table = updated_fl,
        field_names = ["s_id", "type"],
        where_clause = where_clause
    )
}

arcpy.AddMessage(f"{len(update_dict)} points found")

########################################################################################
## APPLY THE CHANGES ###################################################################

where_clause = "s_id IN ('{0}')".format("','".join(update_dict.keys()))

with arcpy.da.UpdateCursor(
    in_table = master_fl,
    field_names = ["s_id", "type", "s_score", "overall_score", "dist_score"],
    where_clause = where_clause
) as cursor:
    for row in cursor:
        row[1] = update_dict[row[0]]
        row[2] = scores_dict[row[1]]
        row[3] = row[2] * row[4]
        cursor.updateRow(row)

########################################################################################